#ifdef SIMDJSON_CONDITIONAL_INCLUDE
#error generic/dependencies.h must be included before defining SIMDJSON_CONDITIONAL_INCLUDE!
#endif

#ifndef SIMDJSON_SRC_GENERIC_DEPENDENCIES_H
#define SIMDJSON_SRC_GENERIC_DEPENDENCIES_H

#include <base.h>

#endif // SIMDJSON_SRC_GENERIC_DEPENDENCIES_H