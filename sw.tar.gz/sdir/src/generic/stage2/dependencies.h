#ifndef SIMDJSON_SRC_GENERIC_STAGE2_DEPENDENCIES_H
#define SIMDJSON_SRC_GENERIC_STAGE2_DEPENDENCIES_H

#include <simdjson/dom/document.h>
#include <simdjson/internal/tape_type.h>

#endif // SIMDJSON_SRC_GENERIC_STAGE2_DEPENDENCIES_H