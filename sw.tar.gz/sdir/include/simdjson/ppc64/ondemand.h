#ifndef SIMDJSON_PPC64_ONDEMAND_H
#define SIMDJSON_PPC64_ONDEMAND_H

#include "simdjson/ppc64/begin.h"
#include "simdjson/generic/ondemand/amalgamated.h"
#include "simdjson/ppc64/end.h"

#endif // SIMDJSON_PPC64_ONDEMAND_H
